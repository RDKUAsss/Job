const total = 50;
const ordered = 100;
if (ordered > total)
{
    console.log(`На складі недостатньо товарів!`);
} else {
    console.log(`Замовлення оформлено, з вами зв'яжеться менеджер`);
}

