let name = `Генератор захисного поля`;
let price = 1000;
console.log(`Обрано ${name}, ціна за штуку ${price} кредитів`);
price = 2000;
console.log(`Обрано ${name}, ціна за штуку ${price} кредитів`);
