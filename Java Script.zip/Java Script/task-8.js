const fruits = ['apple', 'plum', 'pear', 'orange', 'banana'];
const firstTwoEls = fruits.slice(0,2);
const nonExtremeEls = fruits.slice(1,fruits.length-1);
const lastTreeEls = fruits.slice(fruits.length-3,fruits.length);